# Write a python program to sort a given list of numbers without using sort() function

numberList = [5,6,3,1,23,5,-3,-1,6,3,4,6,7,8,9,232,4,5,6457,7,8,9]


sortedNumberList = []

# I actually did it without looking from the internet, probably not the best performance.
# Iam not sure which sorting algorithm is this. maybe quicksort?
length = len(numberList)
for i in range(length):
    number = numberList[i]
    placed = False
    for i2 in range(len(sortedNumberList)):
            number2 = sortedNumberList[i2]
            if number >= number2:
                sortedNumberList.insert(i2, number)
                placed = True
                break
            
    if placed is False:
         sortedNumberList.append(number)
        

            
print(",".join(map(str, reversed(sortedNumberList))))
print(",".join(map(str,sorted(numberList))))