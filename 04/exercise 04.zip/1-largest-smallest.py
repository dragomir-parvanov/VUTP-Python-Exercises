numberList = [2, 3, 4, 5, 1]
print(max(numberList))
print(min(numberList))